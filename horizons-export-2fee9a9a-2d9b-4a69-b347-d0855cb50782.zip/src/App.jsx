
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from '@/pages/HomePage';
import GestionPage from '@/pages/GestionPage';
import { Toaster } from '@/components/ui/toaster';

const App = () => {
  return (
    <>
      <Toaster />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/gestion" element={<GestionPage />} />
      </Routes>
    </>
  );
};

export default App;
  