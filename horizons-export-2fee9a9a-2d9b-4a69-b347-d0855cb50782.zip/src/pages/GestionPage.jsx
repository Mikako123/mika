
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PawPrint, User, ListChecks, PlusCircle, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';

const GestionPage = () => {
  const [pets, setPets] = useState([]);
  const [petName, setPetName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const storedPets = localStorage.getItem('vettrack_pets');
    if (storedPets) {
      setPets(JSON.parse(storedPets));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('vettrack_pets', JSON.stringify(pets));
  }, [pets]);

  const handleAddPet = (e) => {
    e.preventDefault();
    if (!petName.trim() || !ownerName.trim()) {
      toast({
        variant: 'destructive',
        title: 'Error al registrar',
        description: 'Por favor, completa el nombre de la mascota y del dueño.',
        duration: 3000,
      });
      return;
    }

    const newPet = {
      id: Date.now(),
      petName: petName.trim(),
      ownerName: ownerName.trim(),
      registrationDate: new Date().toLocaleDateString('es-ES'),
    };

    setPets(prevPets => [newPet, ...prevPets]);
    setPetName('');
    setOwnerName('');
    toast({
      title: '¡Mascota Registrada!',
      description: `${newPet.petName} ha sido añadida exitosamente.`,
      duration: 3000,
      className: 'bg-green-500 text-white',
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: 'spring', stiffness: 100 },
    },
    exit: {
      y: -20,
      opacity: 0,
      transition: { duration: 0.2 }
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-start p-4 sm:p-8 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-gray-100">
      <motion.header 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 120, delay: 0.1 }}
        className="mb-12 text-center w-full max-w-4xl"
      >
        <div className="flex items-center justify-between mb-4">
          <Link to="/" className="flex items-center text-teal-400 hover:text-teal-300 transition-colors">
            <Home className="h-8 w-8 mr-2" />
            <span className="text-lg font-medium">Inicio</span>
          </Link>
          <div className="flex items-center justify-center">
            <PawPrint className="h-16 w-16 text-teal-400 mr-4" />
            <h1 className="text-5xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-teal-400 via-cyan-400 to-sky-500">
              VetTrack
            </h1>
          </div>
          <div className="w-24"> {/* Placeholder for balance */}</div>
        </div>
        <p className="text-xl text-gray-300">Gestión simple y elegante de registros de mascotas.</p>
      </motion.header>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8"
      >
        <motion.div variants={itemVariants}>
          <Card className="shadow-2xl bg-slate-800/70 border-purple-500/50">
            <CardHeader>
              <CardTitle className="flex items-center text-3xl !bg-clip-text !text-transparent !bg-gradient-to-r !from-purple-400 !via-pink-500 !to-orange-400">
                <PlusCircle className="mr-3 h-8 w-8" />
                Registrar Nueva Mascota
              </CardTitle>
              <CardDescription className="text-gray-400">
                Ingresa los datos de la mascota y su dueño.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddPet} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="petName" className="text-lg text-gray-300 flex items-center">
                    <PawPrint className="mr-2 h-5 w-5 text-teal-400" /> Nombre de la Mascota
                  </Label>
                  <Input
                    id="petName"
                    type="text"
                    value={petName}
                    onChange={(e) => setPetName(e.target.value)}
                    placeholder="Ej: Firulais, Luna"
                    className="bg-slate-700/50 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ownerName" className="text-lg text-gray-300 flex items-center">
                    <User className="mr-2 h-5 w-5 text-sky-400" /> Nombre del Dueño
                  </Label>
                  <Input
                    id="ownerName"
                    type="text"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    placeholder="Ej: Juan Pérez, María García"
                    className="bg-slate-700/50 border-slate-600 text-gray-100 placeholder-gray-500 focus:ring-sky-500 focus:border-sky-500"
                  />
                </div>
                <Button type="submit" className="w-full text-lg py-3 bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-600 hover:to-cyan-700 text-white font-semibold neumorphic-button !shadow-[0_0_0_0_hsl(var(--primary)/0.7),0_0_0_0_hsl(var(--primary)/0.3),inset_0_0_0_0_hsl(var(--primary)/0.5),inset_0_0_0_0_hsl(var(--primary)/0.8)]">
                  <PlusCircle className="mr-2 h-6 w-6" />
                  Añadir Mascota
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="shadow-2xl bg-slate-800/70 border-purple-500/50">
            <CardHeader>
              <CardTitle className="flex items-center text-3xl !bg-clip-text !text-transparent !bg-gradient-to-r !from-purple-400 !via-pink-500 !to-orange-400">
                <ListChecks className="mr-3 h-8 w-8" />
                Mascotas Registradas
              </CardTitle>
              <CardDescription className="text-gray-400">
                {pets.length > 0 ? `Total: ${pets.length} mascotas` : "Aún no hay mascotas registradas."}
              </CardDescription>
            </CardHeader>
            <CardContent className="max-h-[400px] overflow-y-auto pr-2">
              {pets.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-8"
                >
                  <img alt="Cute puppy waiting" class="mx-auto h-32 w-32 mb-4 opacity-70" src="https://images.unsplash.com/photo-1700974103947-215dca5f53c4" />
                  <p className="text-gray-400 text-lg">¡Parece que no hay ninguna mascota aquí!</p>
                  <p className="text-gray-500">Usa el formulario para añadir la primera.</p>
                </motion.div>
              ) : (
                <motion.ul variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
                  <AnimatePresence>
                    {pets.map((pet) => (
                      <motion.li
                        key={pet.id}
                        variants={itemVariants}
                        exit="exit"
                        layout
                        className="p-4 rounded-lg bg-slate-700/60 border border-slate-600 shadow-md hover:shadow-purple-500/30 transition-shadow duration-300"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-xl font-semibold text-teal-300 flex items-center">
                              <PawPrint size={20} className="mr-2 text-teal-400" /> {pet.petName}
                            </h3>
                            <p className="text-sm text-gray-400 flex items-center mt-1">
                              <User size={16} className="mr-2 text-sky-400" /> Dueño: {pet.ownerName}
                            </p>
                          </div>
                          <div className="text-right">
                            <span className="text-xs text-gray-500">Registrado:</span>
                            <p className="text-sm text-gray-300">{pet.registrationDate}</p>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </motion.ul>
              )}
            </CardContent>
             {pets.length > 0 && (
              <CardFooter className="text-sm text-gray-500 pt-4 border-t border-slate-700">
                <p>Mostrando las últimas mascotas registradas.</p>
              </CardFooter>
            )}
          </Card>
        </motion.div>
      </motion.div>
      <footer className="mt-16 text-center text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} VetTrack. Creado con cariño para los amantes de las mascotas.</p>
        <p>Desarrollado por Hostinger Horizons.</p>
      </footer>
    </div>
  );
};

export default GestionPage;
  