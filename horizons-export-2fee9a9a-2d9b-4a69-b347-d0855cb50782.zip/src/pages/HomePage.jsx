
import React from 'react';
import { motion } from 'framer-motion';
import { PawPrint, ShieldCheck, Users, HeartHandshake } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const cardVariants = {
    offscreen: {
      y: 50,
      opacity: 0,
    },
    onscreen: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        bounce: 0.4,
        duration: 0.8,
      },
    },
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-8 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-gray-100 overflow-hidden">
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="container mx-auto text-center"
      >
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 100, delay: 0.2 }}
          className="mb-12"
        >
          <PawPrint className="h-24 w-24 text-teal-400 mx-auto mb-6" />
          <h1 className="text-6xl md:text-7xl font-extrabold tracking-tight mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-teal-400 via-cyan-400 to-sky-500">
              Bienvenido a VetTrack
            </span>
          </h1>
          <p className="text-2xl md:text-3xl text-gray-300 mb-10 max-w-3xl mx-auto">
            La solución moderna y amigable para el registro y gestión de tus queridas mascotas.
          </p>
          <Link to="/gestion">
            <Button size="lg" className="text-xl py-7 px-10 bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-600 hover:to-cyan-700 text-white font-semibold neumorphic-button !shadow-[0_0_0_0_hsl(var(--primary)/0.7),0_0_0_0_hsl(var(--primary)/0.3),inset_0_0_0_0_hsl(var(--primary)/0.5),inset_0_0_0_0_hsl(var(--primary)/0.8)]">
              Comenzar a Registrar Mascotas
            </Button>
          </Link>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 max-w-5xl mx-auto"
          initial="offscreen"
          whileInView="onscreen"
          viewport={{ once: true, amount: 0.3 }}
          transition={{ staggerChildren: 0.2 }}
        >
          <motion.div variants={cardVariants} className="p-8 rounded-xl bg-slate-800/70 border border-purple-500/50 shadow-2xl glassmorphic-card">
            <ShieldCheck className="h-16 w-16 text-green-400 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2 text-green-300">Seguro y Confiable</h2>
            <p className="text-gray-400">
              Tus datos están protegidos. Accede a la información de tus mascotas cuando lo necesites.
            </p>
          </motion.div>
          <motion.div variants={cardVariants} className="p-8 rounded-xl bg-slate-800/70 border border-purple-500/50 shadow-2xl glassmorphic-card">
            <Users className="h-16 w-16 text-sky-400 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2 text-sky-300">Fácil de Usar</h2>
            <p className="text-gray-400">
              Una interfaz intuitiva diseñada para que registrar y consultar sea un proceso sencillo y rápido.
            </p>
          </motion.div>
          <motion.div variants={cardVariants} className="p-8 rounded-xl bg-slate-800/70 border border-purple-500/50 shadow-2xl glassmorphic-card">
            <HeartHandshake className="h-16 w-16 text-pink-400 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2 text-pink-300">Cuidado Centralizado</h2>
            <p className="text-gray-400">
              Mantén un historial completo de todas las mascotas en un solo lugar, accesible desde cualquier dispositivo.
            </p>
          </motion.div>
        </motion.div>
        
        <motion.div 
          className="mt-20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          <img  alt="Happy pets collage" class="mx-auto rounded-lg shadow-xl max-w-2xl w-full h-auto opacity-80" src="https://images.unsplash.com/photo-1636992481531-b21590b99b2f" />
        </motion.div>

      </motion.main>
      <footer className="mt-16 text-center text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} VetTrack. Todos los derechos reservados.</p>
        <p>Simplificando el cuidado de tus mascotas.</p>
      </footer>
    </div>
  );
};

export default HomePage;
  